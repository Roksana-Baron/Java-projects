package com.example.fragmenty;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Toast;

import java.util.Random;

//implementacja View.OnClickListener potrzebnego do nasłuchiwania przucisków i tworzenia na nich funkcji
public class Fragment1 extends Fragment implements View.OnClickListener{

    // zdefiniowanie zmiennych potrzebnych do wykorzystania w późniejszym czasie
    private SeekBar seekBar;
    private Button Button1;
    private Random losowanie;
    private int max;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_1, container, false);

        //przypisanie seekBar i przycisku do funkcji znajdująch dany element na widoku aplikacji (wcześniej zdefiniowane w xml)
        seekBar = v.findViewById(R.id.seekBar);
        Button1 = v.findViewById(R.id.Button1);

        //ustawienie nasłuchiwania zdarzeń dotyczących Button1
        Button1.setOnClickListener(this);

        //ustawienie minimalnej i maksymalnej wartości seekBaru
        seekBar.setMax(50);
        seekBar.setMin(6);
        //przypisanie do zmiennej losowanie wylosowanej liczby
        losowanie= new Random();

        return v;

    }

    @Override
    public void onClick(View view) {
        //stworzenie funkcji która zadziała w momencie wciśnięcia Button1
        if (view.getId() == R.id.Button1){
        /* stworzenie nowej zmiennej lokalnej do której dopisujemy zmienną losowanie
             (generujemy losową liczbę, ale ustalamy maksymalną wartość tego losowania na wartość postępu pobraną z SeekBar.
            Innymi słowy, maksymalna liczba, jaką możemy wylosować, zależy od tego, jak daleko przesunięty jest pasek SeekBar */
            int a=losowanie.nextInt(seekBar.getProgress());
            /* stworzenie tekstu wyświetlającego się na ekranie w czasie oznaczonym jako LONG,
             w tekscie wyświetlana jest zmienna do której dopisujemy " " w celu zmiany formatu na ciąg znaków */
            Toast.makeText(getContext(), a + " ",Toast.LENGTH_LONG).show();
        }

    }
}