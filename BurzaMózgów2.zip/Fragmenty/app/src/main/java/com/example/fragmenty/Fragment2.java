package com.example.fragmenty;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

//implementacja View.OnClickListener potrzebnego do nasłuchiwania przucisków i tworzenia na nich funkcji
public class Fragment2 extends Fragment implements View.OnClickListener{

    // zdefiniowanie zmiennych potrzebnych do wykorzystania w późniejszym czasie
    private EditText numberAText;
    private EditText numberBText;
    private Button button;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_2, container, false);

        //przypisanie przycisku do funkcji znajdującej dany element na widoku aplikacji (wcześniej zdefiniowane w xml)
        button = v.findViewById(R.id.button);
        //ustawienie nasłuchiwania zdarzeń dotyczących button
        button.setOnClickListener(this);

        //przypisanie numberAText i numberBText do funkcji znajdującej dany element na widoku aplikacji (wcześniej zdefiniowane w xml)
        numberAText = v.findViewById(R.id.numberAText);
        numberBText = v.findViewById(R.id.numberBText);


        return v;

    }

    @Override
    public void onClick(View view) {
        //numberAText.getText();
        //numberBText.getText();

        try {
            //Pobiera wartość wprowadzoną przez użytkownika w polu tekstowym numberAText i konwertuje ją na liczbę całkowitą do zmiennej numberA
            int numberA = Integer.parseInt(numberAText.getText().toString());
            //Pobiera wartość wprowadzoną przez użytkownika w polu tekstowym numberBText i konwertuje ją na liczbę całkowitą do zmiennej numberB
            int numberB = Integer.parseInt(numberBText.getText().toString());

            /* Jeżeli zmienna numberB jest różna od 0 i numberA dzieli się przez numberB bez reszty, to wyświetli się komunikat,
            że Liczba B dzieli liczbę A bez reszty, jest to komunikat o długości oznaczonej jako SHORT */
            if (numberB != 0 && numberA % numberB == 0) {
                Toast.makeText(getActivity(), "Liczba B dzieli liczbę A bez reszty.", Toast.LENGTH_SHORT).show();
            /*jeżeli zaś numberB jest równe 0,  wyświetli się komunikat:
                "Wprowadź liczbę różną od zera w polu B!", jest to komunikat o długości oznaczonej jako SHORT */
            } else if (numberB == 0 ){
                Toast.makeText(getActivity(), "Wprowadź liczbę różną od zera w polu B!", Toast.LENGTH_SHORT).show();
            /*w innym wypadku wyświetli się komunikat:
                "Liczba B nie dzieli liczby A bez reszty.", jest to komunikat o długości oznaczonej jako SHORT */
            }else {
                Toast.makeText(getActivity(), "Liczba B nie dzieli liczby A bez reszty.", Toast.LENGTH_SHORT).show();
            }
        //Blok try-catch jest używany do przechwycenia wyjątków
        //NumberFormatException - Jeśli wprowadzone dane nie mogą być skonwertowane na liczby całkowite
        } catch (NumberFormatException e) {
            Toast.makeText(getActivity(), "Wprowadź poprawne liczby!", Toast.LENGTH_SHORT).show();
        //ArithmeticException - Jeśli próba dzielenia przez zero zostanie wykryta
        } catch (ArithmeticException e) {
            Toast.makeText(getActivity(), "Nie można dzielić przez zero!", Toast.LENGTH_SHORT).show();
        }
    }

    }
