package com.example.fragmenty;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Bundle;

public class MainActivity extends FragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ViewPager2 vp = (ViewPager2) findViewById(R.id.viewPager);
        SlidePagerAdapter adapter = new SlidePagerAdapter(this);
        adapter.addFragment(new Fragment1());
        adapter.addFragment(new Fragment2());
        vp.setAdapter(adapter);

    }

}