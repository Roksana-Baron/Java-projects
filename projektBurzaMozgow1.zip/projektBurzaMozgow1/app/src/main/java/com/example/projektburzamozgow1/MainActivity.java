package com.example.projektburzamozgow1;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import android.widget.EditText;


//import com.google.android.material.textfield.TextInputLayout;

import java.util.Random;

/*implementacja View.OnClickListener i CompoundButton.OnCheckedChangeListener
w celu nasłuchiwania i tworzenia funkcji dla przycisków i CheckBoxów */
public class MainActivity extends AppCompatActivity implements View.OnClickListener, CompoundButton.OnCheckedChangeListener {

    //stworzenie zmiennych
    private int secretNumber = 0; //domyślnie dla sekretnej liczby
    private int maxTries = 5;
    int minRange = 1;
    int maxRange = 10;
    private int triesLeft;
    private boolean limitTries;
    private EditText text_guess; //tekst z liczba wybrana przez użytkownika
    private Button check_guess; //sprawdz -> sprawdza, czy numer jest poprawny

    private Button _losuj_Button; //Losuj -> wygeneruje numer według wcześniej wybranych liczby
    private CheckBox checkBox; // Wybór maksymalnie 5 prób
    private RadioGroup radioGroup;// Grupue wszystkie poziomy trudności
    private Random losowanie;
    private RadioButton button_easy; //Poziom łatwy (1-10) -> Potrzebujemy aby móc zaznaczyć lub odznaczyć tą opcję
    private RadioButton button_medium; //Poziom średni (1-50) -> Potrzebujemy aby móc zaznaczyć lub odznaczyć tą opcję
    private RadioButton button_hard; //Poziom trudny(1-100) -> Potrzebujemy aby móc zaznaczyć lub odznaczyć tą opcję
    private int _guessed_number;  //Aby przechowac wybrana liczbe
    private Button _restartButton; //przycisk, który aktywuje się, gdy jesteśmy w trakcie zgadywania, dzięki czemu możemy ponownie losować
    private Button _winStartButton;  //przycisk wyświetlany, gdy użytkownik wygra

    private ImageView _thumbsUpImage;  //Obrazek dla zwycięzcy c:


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        radioGroup  = findViewById(R.id.radioGroup);
        radioGroup.check(R.id.button_easy); //tryb łatwy jest domyślnie zaznaczony
        text_guess = findViewById(R.id.text_guess);
        check_guess = findViewById(R.id.check_guess);
        check_guess.setEnabled(false); //przycisk odgadnięcia wyboru powinien być wyszarzony początkowo
        checkBox = findViewById(R.id.checkBox);
        button_easy = findViewById(R.id.button_easy);
        button_medium = findViewById(R.id.button_medium);
        button_hard = findViewById(R.id.button_hard);
        _losuj_Button = findViewById(R.id.losuj);
        _winStartButton = findViewById(R.id.Start);
        _winStartButton.setVisibility(View.GONE); //przycisk start wyświetla się tylko wtedy, gdy wygramy
        _winStartButton.setEnabled(false);//upewnienie się, że użytkownik nie może go kliknąć
        _restartButton = findViewById(R.id.restart);
        _restartButton.setEnabled(false); //ten przycisk można kliknąć tylko wtedy, gdy użytkownik jest na etapie zgadywania (aby uruchomić ponownie)
        _thumbsUpImage = findViewById(R.id.thumbsup);
        _thumbsUpImage.setVisibility(View.GONE); //zwycięzki obraz jest wyświetlany tylko wtedy, gdy wygrywamy

        _losuj_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                _losuj();
            }
        });
        check_guess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                _check_this_guess();
            }
        });
        _restartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                _restart();
            }
        });
        _winStartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                _restart();
            }
        });
        //text_guess.setOnClickListener(this);
        checkBox.setOnCheckedChangeListener(this);

    }

    public void _losuj ()
    {
//sprawdzanie opcji wybranych przez użytkownika
        if (radioGroup.getCheckedRadioButtonId() == -1)
        {
// żadne przyciski opcji nie są zaznaczone, domyślnie możemy wybrać opcję Easy
            maxRange = 10;
            Toast.makeText(MainActivity.this, "default",Toast.LENGTH_SHORT).show();
        }
        else
        {
            if(radioGroup.getCheckedRadioButtonId() == R.id.button_easy)
            {maxRange = 10;}
            else if (radioGroup.getCheckedRadioButtonId() == R.id.button_medium)
            {maxRange = 50;}
            else if (radioGroup.getCheckedRadioButtonId() == R.id.button_hard)
            {maxRange = 100;}
        }

//sprawdź, czy użytkownik chce limitu zgadywania
        limitTries = false;
        if(checkBox.isChecked())
        {
            limitTries = true;
            triesLeft = 5;
        }

        secretNumber = generateRandomNumber(1, maxRange);

        Toast.makeText(MainActivity.this, "Generowana liczba 1 - " + maxRange ,Toast.LENGTH_SHORT).show();

//możemy wyszarzić przycisk Losuj + przyciski konfiguracji i włączyć teraz przycisk restartu + włączyć zgadywanie
        _losuj_Button.setEnabled(false);
        button_easy.setEnabled(false);
        button_medium.setEnabled(false);
        button_hard.setEnabled(false);
        checkBox.setEnabled(false);

        _restartButton.setEnabled(true);
        check_guess.setEnabled(true);
    }

    public void _check_this_guess() {
        try {
//prosta obsługa błędów, „spróbujmy” zamienić domysł na liczbę, jeśli się nie uda, wyłapiemy ten błąd
            _guessed_number = Integer.parseInt(text_guess.getText().toString());
        } catch (Exception e) {
//„złapaliśmy” błąd, gdy próbowaliśmy przekonwertować dane wprowadzone przez użytkownika na liczbę:
            Toast.makeText(MainActivity.this, "Could not convert the guess to a number", Toast.LENGTH_SHORT).show();
            text_guess.getText().clear();
            return; //w takim przypadku możemy wyjść z tej funkcji
        }

        if (secretNumber == 0) {
            return;
        } //Nie ma żadnej wygenerowanej liczby


//sprawdź, czy numer jest poza zakresem
        if (_guessed_number < minRange || _guessed_number > maxRange) {

            Toast.makeText(MainActivity.this, "Podaj liczbę z zakresu " + minRange + " - " + maxRange, Toast.LENGTH_SHORT).show();

//nie chcemy, aby liczyło się to jako domysł, więc w tym przypadku możemy również wyjść:
            text_guess.getText().clear();
            return;
        }

//Znalezione!- Jeżeli podana liczba jest sekretną liczbą
        if (_guessed_number == secretNumber) {
            Toast.makeText(MainActivity.this, "Gratulacje! Zgadłeś liczbę!", Toast.LENGTH_SHORT).show();
            text_guess.getText().clear();
            secretNumber = 0;

//Wyszarzenie przycisku zgadywania
            check_guess.setEnabled(false);

//Pokazanie obrazku dla zwyciezcy
            _winStartButton.setEnabled(true);
            _winStartButton.setVisibility(View.VISIBLE);
            _thumbsUpImage.setVisibility(View.VISIBLE);

            return;
        }

        if (_guessed_number < secretNumber) {
            if (limitTries) {
                triesLeft--;
                if (triesLeft == 0) {
                    Toast.makeText(MainActivity.this, "Przegrałeś! Koniec prób. Nowa liczba została wylosowana.", Toast.LENGTH_SHORT).show();

//Stworzenie nowej liczby i wyjście
                    _losuj();
                    text_guess.getText().clear();
                    return;
                }
                Toast.makeText(MainActivity.this, "Zła liczba! Pozostało prób: " + triesLeft, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity.this, "Zła liczba! ", Toast.LENGTH_SHORT).show();
            }
        } else {
            if (limitTries) {
                triesLeft--;
                if (triesLeft == 0) {
                    Toast.makeText(MainActivity.this, "Przegrałeś! Koniec prób. Nowa liczba została wylosowana.", Toast.LENGTH_SHORT).show();

//Stworzenie nowej liczby i wyjście
                    _losuj();
                    text_guess.getText().clear();
                    return;
                }
                Toast.makeText(MainActivity.this, "Za duża liczba! Pozostało prób: " + triesLeft, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity.this, "Za duża liczba! ", Toast.LENGTH_SHORT).show();
            }
        }

        text_guess.getText().clear();
    }

    private void _restart()
    {
        //Wyłącza przycisk restartu
        _restartButton.setEnabled(false);

        //włacza przyciski parametrów
        _losuj_Button.setEnabled(true);
        button_easy.setEnabled(true);
        button_medium.setEnabled(true);
        button_hard.setEnabled(true);
        checkBox.setEnabled(true);

        //Wyłącza przycisk zgadywanie
        check_guess.setEnabled(false);

        //Ustawia brak obrazku zwycięzcy i przycisku startu jeśli są widoczne
        _winStartButton.setVisibility(View.GONE);
        _winStartButton.setEnabled(false);
        _thumbsUpImage.setVisibility(View.GONE);
    }

    @Override
    public void onClick(View view) {}



    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

        if (buttonView == checkBox) {
            triesLeft = maxTries;

        }}




    private void showWinScreen()
    {}

    private int generateRandomNumber(int min, int max) {
        Random random = new Random();
        return random.nextInt(max - min + 1) + min;
    }

    private void displayToast(String message) {
        Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
    }

    private void displayToastAndReset(String message) {
        displayToast(message);
        secretNumber = 0;
    }
}